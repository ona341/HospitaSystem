package com.company;
//Onyinyechi Aghaizu
//11284287
//ona341
import java.util.TreeMap;

public class DoctorMapAccess {
    private static final TreeMap<String, Doctor> doctors=new TreeMap<>();

    //    private static
    public static TreeMap <String,Doctor> getInstance(){
        return doctors;
    }
}
