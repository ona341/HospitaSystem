package com.company;

public class IOAccess {
    public static InputOutputInterface io;
    private IOAccess() {

    }
    public static InputOutputInterface getInstance(){
        if (io==null){
        InputOutputInterface pickio=new DialogIO(){};
        String[] options=new String [2];
        options[0]="\n\t1: ConsoleIO";
        options[1]="\n\t2: DialogIO";
        int picked=pickio.readChoice(options);
        if (picked==0 ){
            io=new ConsoleIO();
        }
        else if (picked==1){
            io=new DialogIO(){};
        }
        else
            pickio.outputString("Invalid choice.");
        }

        return io;
    }
}
