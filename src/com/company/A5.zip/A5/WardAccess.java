package com.company;

import java.util.TreeMap;

public class WardAccess {
    private static Ward ward;
    //    private static
private WardAccess(){

}
    public static void initialize(String name,int first,int last){
        if(ward!=null){
            throw new IllegalCallerException("Ward has been created already");
        }
        ward=new Ward(name,first,last);
    }
    public static Ward getInstance(){
        if(ward==null){
            throw new IllegalCallerException("Ward has not been created");
        }
        return ward;
    }
}
