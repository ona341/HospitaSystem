package com.company;


/**
 * A simple hospital system with only one ward.  Patients and doctors can be created,
 * and patients assigned to a doctor and/or placed in a bed of the ward.
 */
public class HospitalSystemA5Q5
{
    /**
     * Initialize an instance of the hospital ward
     * relies on user-input to get the relavent information
     */
    public HospitalSystemA5Q5() {

        IOAccess.getInstance().outputString("\nGetting Ward information...");

        String name =IOAccess.getInstance().readString("\nEnter the name of the Ward: ");
        IOAccess.getInstance().outputString("\nEntered: " + name);
        int firstBedNum = IOAccess.getInstance().readInt("\nEnter the integer label of the first bed: ");
        IOAccess.getInstance().outputString("\nEntered: " + firstBedNum);

        int lastBedNum = IOAccess.getInstance().readInt("\nEnter the integer label of the last bed: ");
        IOAccess.getInstance().outputString("\nEntered: " + lastBedNum);

        WardAccess.initialize(name,firstBedNum,lastBedNum);
    }

    /**
     * Read the information for a new patient and then add the patient
     * to the dictionary of all patients.
     */
    public void addPatient()
    {
        Command cmd = new AddPatient();
        cmd.execute();
    }

    /**
     * Read the information for a new doctor and then add the doctor
     * to the dictionary of all doctors.
     */
    public void addDoctor()
    {
        Command cmd = new AddDoctor ();
        cmd.execute();
    }

    /**
     * Assign a doctor to take care of a patient.
     */
    public void assignDoctorToPatient()
    {
        Command cmd = new AssignDoctorToPatient();
        cmd.execute();
    }

    /**
     * Assign a patient to a specific bed.
     */
    public void assignBed()
    {
        Command cmd = new AssignBed();
        cmd.execute();
    }

    /**
     * Drop the association between a doctor and a patient.
     */
    public void dropAssociation()
    {
        Command cmd = new DropAssociation();
        cmd.execute();
    }

    /**
     * Displays the system state
     */
    public void systemState()
    {
        Command cmd = new SystemState();
        cmd.execute();    }

    /**
     * Display the empty beds for the ward.
     * Method is just a stub, needs to be implemented
     */
    public void displayEmptyBeds()
    {
        Command cmd = new displayEmptyBeds();
        cmd.execute();
    }


    /**
     * Release a patient from the ward.
     * Method is just a stub, needs to be implemented
     */
    public void releasePatient()
    {
        Command cmd = new releasePatient();
        cmd.execute();

    }

    /**
     * Run the hospital system.
     * @param args not used
     */
    public static void main(String[] args){
        int task = -1;
        HospitalSystemA5Q5 sys;

        IOAccess.getInstance().outputString("\nInitializing the system...");

        while (true) {
            // keep trying until the user enters the data correctly
            try {
                sys = new HospitalSystemA5Q5();
                break;
            }
            catch (RuntimeException e) {
                IOAccess.getInstance().outputString(e.getMessage());
            }
        }

        while(task != 1) {
            try
            {
                String[] options=new String [9];
                options[0]="\n\t1: quit";
                options[1]="\n\t2: add a new patient";
                options[2]="\n\t3: add a new doctor";
                options[3]="\n\t4: assign a doctor to a patient";
                options[4]="\n\t5: display the empty beds of the ward";
                options[5]="\n\t6: assign a patient a bed";
                options[6]="\n\t7: release a patient";
                options[7]="\n\t8: drop doctor-patient association";
                options[8]="\n\t9: display current system state\nEnter your selection {1-9}:";


                task = IOAccess.getInstance().readChoice(options)+1;


                if      (task == 1) sys.systemState();
                else if (task == 2) sys.addPatient();
                else if (task == 3) sys.addDoctor();
                else if (task == 4) sys.assignDoctorToPatient();
                else if (task == 5) sys.displayEmptyBeds();
                else if (task == 6) sys.assignBed();
                else if (task == 7) sys.releasePatient();
                else if (task == 8) sys.dropAssociation();
                else if (task == 9) sys.systemState();
                else IOAccess.getInstance().outputString("Invalid option, try again.");
            }
            catch (RuntimeException e) {
                IOAccess.getInstance().outputString(e.getMessage());
            }
        }

    }
}

