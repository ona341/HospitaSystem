package com.company;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;

public class PatientMapAccess {
    private static TreeMap<String, Patient> patients=new TreeMap<>();
    private PatientMapAccess(){

    }
//    private static
public static TreeMap <String,Patient> getInstance(){
return patients;
}

}
